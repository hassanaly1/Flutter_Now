import 'package:flutter/material.dart';

class AppColors {
  static const primaryColor = Colors.green;
}
